									<script type="text/javascript">
                                        $(document).ready(function(){
                                            $('#home').tooltip('show')
                                            $('#home').tooltip('hide')
                                        });
                                    </script>
												<script type="text/javascript">
                                        $(document).ready(function(){
                                            $('#home1').tooltip('show')
                                            $('#home1').tooltip('hide')
                                        });
                                    </script>
									    <script type="text/javascript">
                                        $(document).ready(function(){
                                            $('#login').tooltip('show')
                                            $('#login').tooltip('hide')
                                        });
                                    </script>
										    <script type="text/javascript">
                                        $(document).ready(function(){
                                            $('#signup').tooltip('show')
                                            $('#signup').tooltip('hide')
                                        });
                                    </script>
									
									    <script type="text/javascript">
                                        $(document).ready(function(){
                                            $('#sort').tooltip('show')
                                            $('#sort').tooltip('hide')
                                        });
                                    </script>
									
								
								    <script type="text/javascript">
                                        $(document).ready(function(){
                                            $('#select').tooltip('show')
                                            $('#select').tooltip('hide')
                                        });
                                    </script>
									    <script type="text/javascript">
                                        $(document).ready(function(){
                                            $('#select1').tooltip('show')
                                            $('#select1').tooltip('hide')
                                        });
                                    </script>