			<div class="life-side-bar">
			<div class="hero-container">                  
			
					
			</div>
			
			
		
					
					
							<ul class="nav nav-tabs nav-stacked">
						<li class="">
						<a   href="#"><i class="icon-phone icon-large"></i>&nbsp;Kontak Kami</a>
						</li>
					</ul>
<strong>Alamat</strong>
<p>Tanjung jabung Timur </p>
<p>Telp.:</p>
<p>***</p>
<p>Fax:</p>
<p>*** </p>


			
			</div>
			
	<!-- vision student login -->
	<div id="vision" class="modal hide fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
		<div class="modal-header"><div class="alert alert-info"><strong>Vision</strong></div></div>
		<div class="modal-body">
		<p>By 2017.  Tanjabtim Library.</p>
		</div>
		<div class="modal-footer">
			<button class="btn" data-dismiss="modal" aria-hidden="true"><i class="icon-remove icon-large"></i>&nbsp;Close</button>
		</div>
    </div>
	
	
				    <!-- mission student login -->
	<div id="mission" class="modal hide fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
		<div class="modal-header"><div class="alert alert-info"><strong>Mission</strong></div></div>
		<div class="modal-body">
		<p>
		To nurture students to become productive responsible citizens through the assistance of service - 
		oriented and highly competent internal and external stakeholders working in a harmonious relationship.
		</p>
		</div>
		<div class="modal-footer">
			<button class="btn" data-dismiss="modal" aria-hidden="true"><i class="icon-remove icon-large"></i>&nbsp;Close</button>
		</div>
    </div>