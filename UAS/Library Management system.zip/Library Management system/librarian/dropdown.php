					<li>		
					<a href="borrow.php"  data-toggle="dropdown" ><i class="icon-file icon-large"></i> Transaksi</a>
					<ul class="dropdown-menu">
					<li><a href="borrow.php"><i class="icon-pencil icon-large"></i>&nbsp;Pinjam</a></li>
					<li><a href="view_borrow.php"><i class="icon-reorder icon-large"></i>&nbsp;Buku Yang Dipinjam</a></li>
					<li><a href="return.php"><i class="icon-cog icon-large"></i>&nbsp;Buku Yang Dikembalikan</a></li>
					<li><a href="../Gallery"><i class="icon-book icon-large"></i>&nbsp;Katalog Buku</a></li>
					<li><a target="_blank"href="denda_home.php"><i class="icon-money icon-large"></i>&nbsp;Denda Keterlambatan</a></li>
					</ul>
					</li>