<?php include('header.php'); ?>
<?php include('navbar.php'); ?>
    <div class="container">
		<div class="margin-top">
			<div class="row">	
			<?php include('head.php'); ?>
				
				<div class="text_content">
					
					<table width="450" style="margin: 0pt auto;">
	
	<thead align="center"><tr><th style="text-align: center;"><h3>JAM KERJA</h3></th></tr></thead>
	<tbody>
	<tr>
		<td style="text-align: center;">Senin - Sabtu</td>
	</tr>
	<tr>
		<td style="text-align: center;">08:00 Wib - 17:00 Wib</td>
	</tr>
	</tbody>
	</table>
	
	<table class="staff" >
	<thead>
	<tr>
		<th colspan="5" width="100%" style="text-align: center;"><h3>Staff Perpustakaan</h3></th>
	</tr>
	</thead>
	<tbody>
	<tr>
		<td width="250px"><b>Kepala Kantor</b></td>
		<td width="250px"><b>Kasubag Tata Usaha</b></td>
		<td width="250px"><b>Kasi Akuisisi</b></td>
		<td width="250px"><b>Kasi Pengelolaan</b></td>
		<td width="250px"><b>Kasi Pengembangan</b></td>
	</tr>
	<tr>
		<td width="20%">Aruji, S.sos.</td>
		<td width="20%">Disti Wulandari, S.Pd.</td>
		<td width="20%">Rijal Efendi, S.pd.</td>
		<td width="20%">Muhammad Rois, S.E.</td>
		<td width="20%">Al-Fajri</td>
	</tr>
	
	</tbody>
	</table>
					
					</div>
					</div>
			
		</div>
    </div>
<?php include('footer.php') ?>