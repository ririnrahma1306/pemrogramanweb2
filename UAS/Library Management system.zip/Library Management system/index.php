<?php include('header.php'); ?>
<?php include('navbar.php'); ?>
    <div class="container">
		<div class="margin-top">
			<div class="row">
					<?php include('head.php'); ?>
				<div class="span2">
					<?php include('sidebar.php'); ?>
				</div>
				<div class="span10">
					<?php include('slider.php'); ?>
				</div>
			
				<div class="span2">
				<h4></h4>
			
				</div>
				<div class="span10">
				
				
				
				
					
					<div class="text_content">
					<div class="abc">
					<!-- text content -->
					<h4>Visi</h4>
					<hr>
					<p>
					Mewujudkan masyarakat berkualitas dan sadar informasi.
					</p>
					<hr>
					<h4>Misi</h4>
					<hr>
					<p>Mewujudkan layanan prima terhadap msyarakat</p>
					<p>Mewujudkan masyarakat gemar membaca dan belajar</p>
					<p>Memberikan layanan perpustakaan kedesa terisolir dan terpencil</p>
					<hr>
					</div>
					</div>
					<!-- end content -->
				
				
				</div>
			
			</div>
		</div>
    </div>
<?php include('footer.php') ?>
<?php include('thumbnail.php'); ?>