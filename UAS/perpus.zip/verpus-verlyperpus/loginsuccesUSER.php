<script language="JavaScript">alert('LOGIN SUKSES');
document.location=('ver_indexUSER.php')</script>