<?php session_start();
session_destroy(); 
?>
<script language="JavaScript">alert('BERHASIL LOGOUT');
document.location=('login.php')</script>