<script language="JavaScript">alert('Data Berhasil Di Hapus!');
document.location=('ver_lihat.php')</script>