<script language="JavaScript">alert('Data Berhasil Di Rubah!');
document.location=('ver_lihat.php')</script>