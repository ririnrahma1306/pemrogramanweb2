<!--VERLY ANANDA INDEX-->
<?php include"ver_atasUSER.php";?>
<?php include"ver_menusandsliderUSER.php";?>				
<?php include"ver_bawahUSER.php";?>		

							
						