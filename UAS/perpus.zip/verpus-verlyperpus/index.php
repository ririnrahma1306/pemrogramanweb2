<!--VERLY ANANDA INDEX-->
<?php include"ver_atas.php";?>
<?php include"ver_menusandslider.php";?>				
<?php include"ver_bawah.php";?>		

							
						