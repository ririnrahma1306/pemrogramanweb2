<script language="JavaScript">alert('LOGIN SUKSES');
document.location=('index.php')</script>