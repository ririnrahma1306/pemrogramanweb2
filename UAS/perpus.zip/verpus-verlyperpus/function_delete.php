function warning() {
	return confirm('Are You Sure to Delete This Data?');
}