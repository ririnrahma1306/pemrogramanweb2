<script language="JavaScript">alert('Data Berhasil Di Hapus!');
document.location=('FormView.php')</script>