<!---VERLI FROM-->
								<br>	
									<br>
										<br>
						<div class="row">
						<!---verli rata tengah-->
						<div class="col-md-12 col-lg-2 col-sm-12">
						</div>
						<!---verli rata END-->
							<div class="col-lg-8 col-md-5">
								<div class="panel uploads">
									<div class="panel-body panel-portfolio no-padding">
										<div class="portfolio-grid portfolio-hover">
											<div class="overlayer bottom-left fullwidth">
												<div class="overlayer-wrapper">
													<div class="padding-20">
														<h4 class="text-white no-margin">Recent Uploads</h4>
														<h5 class="text-white">Take a look at what other users are uploading right now</h5>
													</div>
												</div>
											</div>
											<div class="e-slider owl-carousel owl-theme portfolio-grid portfolio-hover" data-plugin-options='{"pagination": false, "stopOnHover": true}'>
												<div class="item">
													<img src="assets/images/image01.jpg" alt="">
													<div class="caption">
														<h2 class="caption-title">Hover Style #10</h2>
														<p class="caption-description">
															A wonderful serenity has taken possession of my entire soul, like these sweet mornings of spring which I enjoy with my whole heart.
														</p>
														<a href="#" class="caption-button">
															Read More
														</a>
													</div>
												</div>
												<div class="item">
													<img src="assets/images/image02.jpg" alt="">
													<div class="caption">
														<h2 class="caption-title">Hover Style #10</h2>
														<p class="caption-description">
															A wonderful serenity has taken possession of my entire soul, like these sweet mornings of spring which I enjoy with my whole heart.
														</p>
														<a href="#" class="caption-button">
															Read More
														</a>
													</div>
												</div>
												<div class="item">
													<img src="assets/images/image03.jpg" alt="">
													<div class="caption">
														<h2 class="caption-title">Hover Style #10</h2>
														<p class="caption-description">
															A wonderful serenity has taken possession of my entire soul, like these sweet mornings of spring which I enjoy with my whole heart.
														</p>
														<a href="#" class="caption-button">
															Read More
														</a>
													</div>
												</div>
												<div class="item">
													<img src="assets/images/image04.jpg" alt="">
													<div class="caption">
														<h2 class="caption-title">Hover Style #10</h2>
														<p class="caption-description">
															A wonderful serenity has taken possession of my entire soul, like these sweet mornings of spring which I enjoy with my whole heart.
														</p>
														<a href="#" class="caption-button">
															Read More
														</a>
													</div>
												</div>
											</div>
										</div>
										<div class="partition partition-white padding-15">
											<div class="navigator">
												<a href="#" class="circle-50 partition-white owl-prev"><i class="fa fa-chevron-left text-extra-large"></i></a>
												<a href="#" class="circle-50 partition-white owl-next"><i class="fa fa-chevron-right text-extra-large"></i></a>
											</div>
											<div class="clearfix space5">
												<div class="col-xs-12 text-center no-padding space10">
											Welcome To <b> Verpus-VerlyAnanda</b> Perpustakaan
												</div>
												<div class="col-xs-12 text-center no-padding">
													<a class="tags">
														New York
													</a>
													<a class="tags">
														London
													</a>
													<a class="tags">
														Rome
													</a>
													<a class="tags">
														Paris
													</a>
													<a class="tags">
														Berlin
													</a>
													<a class="tags">
														Amsterdam
													</a>
													<a class="tags">
														Madrid
													</a>
												</div>
											</div>
											<div class="clearfix padding-5">
												<div class="col-xs-4 text-center no-padding">
													<div class="border-right border-dark">
														<a href="#" class="text-dark">
															<i class="fa fa-heart-o text-red"></i> 250
														</a>
													</div>
												</div>
												<div class="col-xs-4 text-center no-padding">
													<div class="border-right border-dark">
														<a href="#" class="text-dark">
															<i class="fa fa-bookmark-o text-green"></i> 20
														</a>
													</div>
												</div>
												<div class="col-xs-4 text-center no-padding">
													<a href="#" class="text-dark"><i class="fa fa-comment-o text-azure"></i> 544</a>
												</div>
											</div>
										</div>
									</div>
								</div>
							</div>
							</div>
						
							<!--- INPUT DAN LIHAT-->
							<div class="row">
							<!---verli rata tengah-->
						<div class="col-md-12 col-lg-2 col-sm-12">
						</div>
						<!---verli rata END-->
								<div class="col-md-4 col-lg-4 col-sm-6">
								<div class="panel panel-default panel-white core-box">
									<div class="panel-tools">
										<a href="#" class="btn btn-xs btn-link panel-close">
											<i class="fa fa-times"></i>
										</a>
									</div>
									<div class="panel-body no-padding">
										<div class="partition-green padding-20 text-center core-icon">
											<i class="fa fa-bar-chart-o fa-2x icon-big"></i>
										</div>
										<div class="padding-20 core-content">
											<h3 class="title block no-margin">INPUT BUKU</h3>
										</div>
									</div>
									<div class="panel-footer clearfix no-padding">
										<div class=""></div>
										<a href="ver_input.php" class="col-xs-4 padding-10 text-center text-white tooltips partition-blue" data-toggle="tooltip" data-placement="top" title="Tambah Buku"><i class="fa fa-plus"></i></a>
									</div>
								</div>
							</div>

								<div class="col-md-4 col-lg-4 col-sm-6">
								<div class="panel panel-default panel-white core-box">
									<div class="panel-tools">
										<a href="#" class="btn btn-xs btn-link panel-close">
											<i class="fa fa-times"></i>
										</a>
									</div>
									<div class="panel-body no-padding">
										<div class="partition-red padding-20 text-center core-icon">
											<i class="fa fa-desktop fa-2x icon-big"></i>
										</div>
										<div class="padding-20 core-content">
											<h3 class="title block no-margin">LIHAT BUKU</h3>
											</div>
									</div>
									<div class="panel-footer clearfix no-padding">
												<a href="ver_lihat.php" class="col-xs-4 padding-10 text-center text-white tooltips partition-red" data-toggle="tooltip" data-placement="top" title="Lihat Buku"><i class="fa fa-chevron-right"></i></a>
									</div>
								</div>
							</div>
							</div>



						<!---VerliFormEnd-->
								</div>
									</div>
									</div>
								</div>
							</div>
						</div>