function warning() {
	return confirm('Yakin Mau Hapus ini Buku ?');
}